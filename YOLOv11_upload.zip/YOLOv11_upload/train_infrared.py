model_yaml_path = r'ultralytics/cfg/models/11/yolo11_TIM_0920.yaml'
data_yaml_path = r'/media/xiyunqiao/bc872771-ead6-4428-a335-7bd27211f5a3/xiyunqiao/YOLOv11/ultralytics/infrared_datasets/infrared_datasets.yaml'
import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO
import time

if __name__ == '__main__':
    model = YOLO(model_yaml_path)
    model = model.float()
    # 如何切换模型版本, 上面的ymal文件可以改为 yolo11s.yaml就是使用的11s,
    # 类似某个改进的yaml文件名称为yolov11-XXX.yaml那么如果想使用其它版本就把上面的名称改为yolov11l-XXX.yaml即可（改的是上面YOLO中间的名字不是配置文件的）！
    dynamic_seed = int(time.time()) % (2 ** 32 - 1)  # 加随机，让结果不固定
    model.train(data=data_yaml_path,
                # 如果任务是其它的'ultralytics/cfg/default.yaml'找到这里修改task可以改成detect, segment, classify, pose
                cache=False,
                imgsz=640,
                epochs=100,
                patience = 20,
                single_cls=True,  # 是否是单类别检测
                batch=24,
                close_mosaic=0,
                workers=8,
                cls=0.7,
                device='0',
                optimizer='SGD',  #默认为auto 最好固定的. 如SGD Adam等
                #resume=True, # 续训的话这里填写True, yaml文件的地方改为lats.pt的地址,需要注意的是设置训练200轮次模型训练了200轮次是没有办法进行续训的.
                #amp=True,  # 如果出现训练损失为Nan可以关闭amp
                project='runs/train',
                name='exp',
                mosaic = 0,
                copy_paste = 0.1,
                seed=dynamic_seed
                )
